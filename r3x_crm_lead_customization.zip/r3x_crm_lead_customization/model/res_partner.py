# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import fields, osv, orm
import urllib2,urllib
from openerp.tools.translate import _

class res_partner(osv.osv):
    _inherit = "res.partner"
    _columns = {
        'is_branch': fields.boolean('Is a Branch' , help="Check this box if this contact is a branch."),
        'run_id': fields.many2one('crm.lead.run', 'Run'),
        'lead_id': fields.many2one('crm.lead', 'Lead'),
        'customer_group_id': fields.many2one('customer.group', 'Customer Group'),
        'class_id': fields.many2one('industry.class', 'Class'),
        'industry_id': fields.many2one('industry.industry', 'Industry'),
        'legacy': fields.char('Legacy Account Code', size=64),
        'territory_id': fields.many2one("res.country.state", 'Territory'),
        'date_incorporated': fields.date('Date Incorporated'),
        'paid_up_capital': fields.float('Paid Up Capital'),
        'est_monthly_purchase': fields.float('Est. Monthly Purchase'),
        'customer_registration': fields.selection([('cod', 'Cash on Delivery'),
                                                   ('trade', 'Trade Account')], 'Customer Type'),
        'send_without_trade_ref': fields.boolean('Sent Without Trade Reference'),
        'email_statement': fields.char('Email ID for Statement', size=64),
        'email_invoice': fields.char('Email ID for Invoice', size=64),
        'sales_head_id':fields.many2one('res.users', 'Sales Manager'),
        'finance_manager_id': fields.many2one('res.users', 'Finance Manager'),
        }

    def onchange_city_name(self, cr, uid, ids, city_id, context):
        if city_id:
            city_obj=self.pool.get('city.city').browse(cr, uid, city_id, context)
            zip =  zip = self.pool.get('city.city').browse(cr, uid, city_id, context).zip
            return {'value': {'state_id': city_obj.state_id and city_obj.state_id.id,
                              'city': city_obj.name,
                              'zip': zip}}
        return True

    def onchange_parent_id(self, cr, uid, ids, parent_id,context=None):
        result = {}
        result['value']={}
        if not parent_id:
            return result
        parent = self.browse(cr, uid, parent_id, context=context)
        result['value'].update({'customer_group_id':parent.customer_group_id and \
                                parent.customer_group_id.id or False,
                       'industry_id':parent.industry_id and parent.industry_id.id or False,
                       'class_id': parent.class_id and parent.class_id.id or False,
                       'customer_group_id':parent.customer_group_id and parent.customer_group_id.id or False,
                        'property_payment_term':parent.property_payment_term and parent.property_payment_term.id or False})
        return result


    def onchange_type(self, cr, uid, ids, is_company, context=None):
        res = super(res_partner, self).onchange_type(cr, uid, ids, is_company, context=context)
        if is_company:
            res['value'].update({'is_branch': False})
        return res


    def onchange_branch(self, cr, uid, ids, is_branch, context=None):
        value = {}
        if is_branch:
            value.update({'is_company': False})
        return {'value': value}

    def generate_sequence(self, cr, uid, vals, context=None):
        ref_name = ''
        obj_sequence = self.pool.get('ir.sequence')
        customer_group_id = vals.get('customer_group_id')
        industry_id = vals.get('industry_id')
        sequence_id = obj_sequence.search(cr, uid, [('industry_id','=',industry_id),('customer_group_id','=',customer_group_id)])
        if sequence_id:
            ref_name = obj_sequence.next_by_id(cr, uid, sequence_id[0],context)
        else:
            industry = self.pool.get('industry.industry').browse(cr,uid,industry_id,context=context)
            customer_group = self.pool.get('customer.group').browse(cr,uid,customer_group_id,context=context)
            if industry.code:
                industry_name = industry.code
            else:
                industry_name = industry.name
            if customer_group.code:
                customer_group_name = customer_group.code
            else:
                customer_group_name = customer_group.name
            res = {
                   'name': industry_name + '-' + customer_group_name,
                   'prefix': industry_name + '/'+ customer_group_name + '/',
                   'padding': 3,
                   'customer_group_id': customer_group_id,
                   'industry_id': industry_id,
                   }
            seq_id = self.pool.get('ir.sequence').create(cr,uid,res,context=context)
            ref_name = obj_sequence.next_by_id(cr, uid, seq_id,context)
        vals.update({'ref': ref_name})
        return True

    def create(self, cr, uid, vals, context=None):
        if vals.get('customer_group_id') and vals.get('industry_id'):
            self.generate_sequence(cr, uid, vals, context)
        new_id = super(res_partner, self).create(cr, uid, vals, context=context)
        return new_id

    def write(self, cr, uid, ids, vals, context=None):
        if isinstance(ids, (int, long)):
            ids = [ids]
        industry_id=0
        customer_group_id=0
        for data in self.browse(cr,uid,ids,context):
             industry_id=data.industry_id.id
             customer_group_id=data.customer_group_id.id

        if vals.get('customer_group_id') and vals.get('industry_id'):
            self.generate_sequence(cr, uid, vals, context)

        elif vals.get('customer_group_id'):
            vals.update({'industry_id':industry_id})
            self.generate_sequence(cr, uid, vals, context)

        elif vals.get('industry_id'):
            vals.update({'customer_group_id':customer_group_id})
            self.generate_sequence(cr, uid, vals, context)

        result = super(res_partner,self).write(cr, uid, ids, vals, context=context)
        return result

res_partner()

class res_partner_bank(osv.osv):
    _inherit = "res.partner.bank"
    _columns = {
               'check': fields.boolean('Check')
               }

res_partner_bank()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
