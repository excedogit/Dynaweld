# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2013 ZestyBeanz Technologies Pvt. Ltd.
#    (http://wwww.zbeanztech.com)
#    contact@zbeanztech.com
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp.addons.base_status.base_stage import base_stage
from openerp.osv import fields, osv
from openerp import SUPERUSER_ID
from openerp.tools.translate import _
from datetime import datetime
from openerp import tools
from base.res.res_partner import format_address

class industry_class(osv.osv):
    _name = "industry.class"
    _columns = {
        'name': fields.char('Name', size=64, required=True),
        'code': fields.char('code', size=8),
        }

industry_class()

class industry_industry(osv.osv):
    _name = "industry.industry"
    _columns = {
        'name': fields.char('Name', size=64, required=True),
        'code': fields.char('code', size=8),
        }

industry_industry()

class crm_lead_run(base_stage,format_address,osv.osv):
    _name = "crm.lead.run"
    _columns = {
        'name': fields.char('Name', size=64, required=True),
        'code': fields.char('code', size=8),
        }
    _order = 'name'

crm_lead_run()

class crm_lead_new(base_stage,format_address,osv.osv):
    _name = "lead.new"
    _order = "priority,date_action,id desc"
    _inherit = ['mail.thread', 'ir.needaction_mixin']


    _track = {
        'state': {
            'crm.mt_lead_create': lambda self, cr, uid, obj, ctx=None: obj['state'] in ['new', 'draft'],
            'crm.mt_lead_won': lambda self, cr, uid, obj, ctx=None: obj['state'] == 'done',
            'crm.mt_lead_lost': lambda self, cr, uid, obj, ctx=None: obj['state'] == 'cancel',
        },
        'stage_id': {
            'crm.mt_lead_stage': lambda self, cr, uid, obj, ctx=None: obj['state'] not in ['new', 'draft', 'cancel', 'done'],
        },
    }


    def onchange_req_credit_details(self, cr, uid, ids, credit_limit=0.00, credit_payment_term_id=False,
                                    context=None):
       res = {}
       res['value'] = {
                       'sm_cr_limit': credit_limit,
                       'sm_property_payment_term': credit_payment_term_id
                       }
       return res

    def onchange_sm_credit_details(self, cr, uid, ids, credit_limit=0.00, sm_payment_term_id=False,
                                   context=None):
        res = {}
        res['value'] = {
                        'fc_cr_limit': credit_limit,
                        'fc_property_payment_term': sm_payment_term_id
                        }
        return res

    def onchange_name(self,cr, uid, ids, name, context=None):
        res = {}
        if name:
            res['value']={'partner_name':name}
        return res

    def onchange_cust_reg(self, cr, uid, ids, customer_registration, context=None):
        res = {}
        if customer_registration and customer_registration == 'cod':
            res['value'] = {'send_without_trade_ref': False}
        return res

    _columns = {
        'street': fields.char('Street', size=128),
        'street2': fields.char('Street2', size=128),
        'zip': fields.char('Zip', change_default=True, size=24),
        'city': fields.char('City', size=128),
        'state_id': fields.many2one("res.country.state", 'State'),
        'country_id': fields.many2one('res.country', 'Country'),
        'phone': fields.char('Phone', size=64),
        'fax': fields.char('Fax', size=64),
        'mobile': fields.char('Mobile', size=64),
        'function': fields.char('Function', size=128),
        'title': fields.many2one('res.partner.title', 'Title'),
        'company_id': fields.many2one('res.company', 'Company', select=1),
        'payment_mode': fields.many2one('crm.payment.mode', 'Payment Mode', \
                            domain="[('section_id','=',section_id)]"),
        'planned_cost': fields.float('Planned Costs'),
            
        'partner_name': fields.char("Customer Name", size=64,
                        help='The name of the future partner company that will be created while converting the lead into opportunity', select=1),
        
        'title': fields.many2one('res.partner.title', 'Title'),
        'name': fields.char('Subject', size=64, select=1),
        'contact_name': fields.char('Contact Name', size=64),
        'country_id': fields.many2one('res.country', 'Country'),
        'email_from': fields.char('Email', size=128, help="Email address of the contact", select=1),
        'phone': fields.char("Phone", size=64),
        'partner_id': fields.many2one('res.partner', 'Partner', ondelete='set null', track_visibility='onchange',
            select=True, help="Linked partner (optional). Usually created when converting the lead."),
        'section_id': fields.many2one('crm.case.section', 'Sales Team',
                        select=True, track_visibility='onchange', help='When sending mails, the default email address is taken from the sales team.'),
        'type_id': fields.many2one('crm.case.resource.type', 'Campaign', \
            domain="['|',('section_id','=',section_id),('section_id','=',False)]", 
            help="From which campaign (seminar, marketing campaign, mass mailing, ...) did this contact come from?"),
        
        'referred': fields.char('Referred By', size=64),  
        'date_action': fields.date('Next Action Date', select=True),
        'date_deadline': fields.date('Expected Closing', help="Estimate of the date on which the opportunity will be won."),
        'channel_id': fields.many2one('crm.case.channel', 'Channel', help="Communication channel (mail, direct, phone, ...)"),       
        'priority': fields.selection([
                           ('draft', 'New'),
                           ('cancel', 'Cancelled'),
                           ('open', 'In Progress'),
                           ('pending', 'Pending'),
                           ('done', 'Closed')
                           ], 'Priority', select=True),
        'state': fields.related('stage_id', 'state', type="selection", store=True,
                selection=[
                           ('draft', 'New'),
                           ('cancel', 'Cancelled'),
                           ('open', 'In Progress'),
                           ('pending', 'Pending'),
                           ('done', 'Closed')
                           ], string="Status", readonly=True, select=True,
                help='The Status is set to \'Draft\', when a case is created. If the case is in progress the Status is set to \'Open\'. When the case is over, the Status is set to \'Done\'. If the case needs to be reviewed then the Status is  set to \'Pending\'.'),

        'stage_id': fields.many2one('crm.case.stage', 'Stage', track_visibility='onchange',
                        domain="['&', '&', ('fold', '=', False), ('section_ids', '=', section_id), '|', ('type', '=', type), ('type', '=', 'both')]",
                        write=['r3x_crm_lead_customization.cus_reg_sale_manager', 'r3x_crm_lead_customization.cus_reg_finance_manager'], 
                        read=['base.group_sale_salesman']),
                
        'date_incoprated': fields.date('Date Incorporated'),
        'paid_up_capital':fields.float("Paid Up Capital"),
        'est_monthly_purchase':fields.float('Est. Monthly Purchases'),
        'bussiness_premise': fields.selection([('leased', 'Leased'), ('rented', 'Rented'),
                                               ('buying', 'Buying'), ('owned', 'Owned')], 'Business Premises'),
        'postal_title': fields.many2one('res.partner.title', 'Title'),
        'postal_street': fields.char('Street', size=128),
        'postal_street2': fields.char('Street2', size=128),
        'postal_zip': fields.char('Zip', size=8),
        'postal_city_id': fields.char('City', size=64),
        'postal_email': fields.char('Email', size=64),
        'postal_telephone': fields.char('Telephone', size=64),
        'postal_mobile': fields.char('Mobile', size=64),
        'postal_fax': fields.char('Fax', size=64),
        'postal_state_id': fields.many2one("res.country.state", 'State'),
        'postal_country_id': fields.many2one('res.country', 'Country'),

        'delivery_name': fields.char('Name', size=128),
        'delivery_title': fields.many2one('res.partner.title', 'Title'),
        'delivery_street': fields.char('Street', size=128),
        'delivery_street2': fields.char('Street2', size=128),
        'delivery_zip': fields.char('Zip', size=8),
        'delivery_city_id': fields.char('City', size=64),
        'delivery_email': fields.char('Email', size=64),
        'delivery_telephone': fields.char('Telephone', size=64),
        'delivery_mobile': fields.char('Mobile', size=64),
        'delivery_fax': fields.char('Fax', size=64),
        'delivery_state_id': fields.many2one("res.country.state", 'State'),
        'delivery_country_id': fields.many2one('res.country', 'Country'),

        'customer_registration': fields.selection([('cod', 'Cash on Delivery'),
                                                   ('trade', 'Trade Account')], 'Customer Type'),
                
        'sales_head':fields.many2one('res.users', 'Sales Manager'),
        'finance_manager': fields.many2one('res.users', 'Finance Manager'),
        'account_trading_name': fields.char('Account Trading Name', size=64),
        'account_abn': fields.char('Account ABN', size=64),
        'account_postal_address1': fields.char('Postal Address', size=128),
        'account_postal_address2': fields.char('Postal Street2', size=128),
        'account_postal_zip': fields.char('Zip', size=24),
        'account_delivery_address1': fields.char('Delivery Address', size=128),
        'account_delivery_address2': fields.char('Delivery Street2', size=128),
        'account_delivery_zip': fields.char('Postcode', size=64),
        'delivery_instructions': fields.char('Delivery Instructions', size=128),
        'account_contact_name': fields.char('Contact Name', size=64),
        'territory_state_id': fields.many2one("res.country.state", 'Territory'),
        'email_from2': fields.char('Email for Statements', size=128),
        'rep': fields.char('REP', size=64),
        'price_list': fields.many2one('product.pricelist', 'PriceList'),
        'run_id': fields.many2one('crm.lead.run', 'Run'),
        'customer_group_id': fields.many2one('customer.group', 'Customer Group'),
        'class_id': fields.many2one('industry.class', 'Class'),
        'industry_id': fields.many2one('industry.industry', 'Industry'),
        'req_cr_limit': fields.float('Req. Credit Limit'),
        'req_cr_term_id': fields.many2one('account.payment.term', 'Req. Credit Terms'),
        'completed_date': fields.date('Creation Date'),
        'sm_cr_limit': fields.float('Suggested Credit Limit'),
        'sm_comments': fields.char('Additional Comments', size=128),
        'sm_aprove_date': fields.date('Approved Date',
                          write=['r3x_crm_lead_customization.cus_reg_sale_manager', 'r3x_crm_lead_customization.cus_reg_finance_manager'], read=['base.group_sale_salesman']),
        'fc_cr_limit': fields.float('Approved Credit Limit'),
        'fc_term_id':fields.char('Approved Terms', size=64),
        'sm_property_payment_term': fields.many2one('account.payment.term', 'Suggested Terms'),
        'fc_property_payment_term': fields.many2one('account.payment.term', 'Approved Terms'),
        'fc_comments': fields.char('Additional Comments', size=128),
        'create_uid': fields.many2one('res.users', 'Created by', readonly=True),
        'fc_aprove_date': fields.date('Approved Date',
                             write=['r3x_crm_lead_customization.cus_reg_sale_manager', 'r3x_crm_lead_customization.cus_reg_finance_manager'], read=['base.group_sale_salesman']),
        'sort_key': fields.char('Sort Key', size=64),
        'account_opened_date': fields.date('Account Opened'),
        'property_receivable_account_id':fields.property(
            'account.account',
            type='many2one',
            relation='account.account',
            string="Account Receivable",
            view_load=True,
            domain="[('type', '=', 'receivable')]",
            help="This account will be used instead of the default one as the receivable account for the current partner",
            required=False),
       'approval_mail_send': fields.boolean('Mail Sent'),
       'mgr_mail_not_send': fields.boolean('Mail Not Sent'),
       'approved_by_manager': fields.boolean('Manager Approved',
                            write=['r3x_crm_lead_customization.cus_reg_sale_manager', 'r3x_crm_lead_customization.cus_reg_finance_manager'], read=['base.group_sale_salesman']),
       'send_without_trade_ref': fields.boolean('Sent Without Trade Reference'),
       'title1': fields.many2one('res.partner.title', 'Title'),
       'approval_sel': fields.selection([('sale_mngr','Approval By Sale Manager'),('finance_mngr','Approval By Finance Manager')], 'Approval By'),
       'is_branch': fields.boolean('Is a Branch' , help="Check this box if this contact is a branch."),
       'parent_id': fields.many2one('res.partner', 'Parent Company'),
       'email_statement': fields.char('Email ID for Statement', size=64),
       'email_invoice': fields.char('Email ID for Invoice', size=64),
       'ref_partner':fields.related('partner_id','ref',type='char',size=64,string="Reference"),
       'create_date': fields.datetime('Creation Date' , readonly=True),
       'user_id': fields.many2one('res.users', 'Salesperson', select=True, track_visibility='onchange'),
       }

    def _create_lead_partner(self, cr, uid, lead, context=None):
        try:
            crm_obj=self.pool.get('crm.lead')
            res = crm_obj._create_lead_partner(cr, uid, lead, context=context)
        except:
            if lead.name:
                res = self._lead_create_contact(cr, uid, lead, lead.name, True, context=context)
            else:
                raise
        return res

    def _lead_create_contact(self, cr, uid, lead, name, is_company, parent_id=False, context=None):
        if lead.is_branch == True:
            is_company = False
        else:
            is_company = True
        crm_obj=self.pool.get('crm.lead')
        res = crm_obj._lead_create_contact(cr, uid, lead, name, is_company, parent_id, context)
        self.pool.get('res.partner').write(cr, uid, res, {
                                                          'email': tools.email_split(lead.postal_email) and tools.email_split(lead.postal_email)[0] or False,
                                                          'street': lead.postal_street,
                                                          'street2': lead.postal_street2,
                                                          'zip': lead.postal_zip,
                                                          'city': lead.postal_city_id.name,
                                                          'city_id': lead.postal_city_id and lead.postal_city_id.id,
                                                          'country_id': lead.postal_country_id and lead.postal_country_id.id or False,
                                                          'state_id': lead.postal_state_id and lead.postal_state_id.id or False,
                                                          'credit_limit': lead.fc_cr_limit,
                                                          'property_payment_term': lead.fc_property_payment_term and lead.fc_property_payment_term.id or False,
                                                          'property_account_recievable': lead.property_receivable_account_id and lead.property_receivable_account_id.id,
                                                          'run_id': lead.run_id and lead.run_id.id or False,
                                                          'property_product_pricelist': lead.price_list and lead.price_list.id,
                                                          'customer_group_id': lead.customer_group_id and lead.customer_group_id.id,
                                                          'class_id': lead.class_id and lead.class_id.id,
                                                          'industry_id': lead.industry_id and lead.industry_id.id,
                                                          'territory_id': lead.territory_state_id and lead.territory_state_id.id,
                                                          'phone': lead.postal_telephone,
                                                          'mobile': lead.postal_mobile,
                                                          'fax': lead.postal_fax,
                                                          'lead_id': lead.id,
                                                          'is_company': is_company,
                                                          'is_branch': lead.is_branch,
                                                          'parent_id': lead.parent_id and lead.parent_id.id or False,
                                                          'date_incorporated': lead.date_incoprated,
                                                          'paid_up_capital': lead.paid_up_capital,
                                                          'est_monthly_purchase': lead.est_monthly_purchase,
                                                          'customer_registration': lead.customer_registration,
                                                          'send_without_trade_ref': lead.send_without_trade_ref,
                                                          'email_statement': lead.email_statement,
                                                          'email_invoice': lead.email_invoice,
                                                          'sales_head_id': lead.sales_head.id,
                                                          'finance_manager_id': lead.finance_manager.id,
                                                          'user_id': lead.user_id.id
                                                          }, context=context)
        return res

    def _lead_create_partner(self, cr, uid, lead, partner_id, context=None):
        res = []
        partner_pool = self.pool.get('res.partner')
        if lead.delivery_name or lead.delivery_street or lead.delivery_street2:
            data = {
                    'name': lead.delivery_name or lead.name,
                    'user_id': lead.user_id and lead.user_id.id,
                    'comment': lead.description,
                    'section_id': lead.section_id and lead.section_id.id or False,
                    'parent_id': partner_id,
                    'email': tools.email_split(lead.delivery_email) and tools.email_split(lead.delivery_email)[0] or False,
                    'street': lead.delivery_street,
                    'street2': lead.delivery_street2,
                    'zip': lead.delivery_zip,
                    'phone': lead.delivery_telephone,
                    'mobile': lead.delivery_mobile,
                    'fax': lead.delivery_fax,
                    'city': lead.delivery_city_id and lead.delivery_city_id.name,
                    'city_id': lead.delivery_city_id and lead.delivery_city_id.id,
                    'country_id': lead.delivery_country_id and lead.delivery_country_id.id or False,
                    'state_id': lead.delivery_state_id and lead.delivery_state_id.id or False,
                    'is_company': False,
                    'type': 'delivery',
                    'title': lead.delivery_title and lead.delivery_title.id or False,
                    'lead_id': lead.id
                    }
            new_partner_id = partner_pool.create(cr, uid, data, context=context)
            res.append(new_partner_id)
        for address_id in lead.address_ids:
            data = {
                    'name': address_id.name,
                    'user_id': lead.user_id and lead.user_id.id,
                    'comment': lead.description,
                    'section_id': lead.section_id and lead.section_id.id or False,
                    'parent_id': partner_id,
                    'email': tools.email_split(address_id.email) and tools.email_split(address_id.email)[0] or False,
                    'street': address_id.street,
                    'street2': address_id.street1,
                    'zip': address_id.zip,
                    'phone': address_id.phone,
                    'mobile': address_id.mobile,
                    'fax': address_id.fax,
                    'city': address_id.city_id and address_id.city_id.name,
                    'city_id': address_id.city_id and address_id.city_id.id,
                    'country_id': address_id.country_id and address_id.country_id.id or False,
                    'state_id': address_id.state_id and address_id.state_id.id or False,
                    'is_company': False,
                    'type': 'contact',
                    'title': address_id.title_id and address_id.title_id.id or False,
                    'lead_id': lead.id
                    }
            new_partner_id = partner_pool.create(cr, uid, data, context=context)
            res.append(new_partner_id)
        return res

    def onchange_stage_id(self, cr, uid, ids, stage_id, context=None):
        if not stage_id:
            return {'value':{}}
        stage = self.pool.get('crm.case.stage').browse(cr, uid, stage_id, context)
        if not stage.on_change:
            return {'value':{}}
        return {'value':{'probability': stage.probability}}

    def onchange_sm_credit_details(self, cr, uid, ids, credit_limit=0.00, sm_payment_term_id=False,
                                   context=None):
        res = {}
        res['value'] = {
                        'fc_cr_limit': credit_limit,
                        'fc_property_payment_term': sm_payment_term_id
                        }
        return res

    def _get_payment_term(self, cr, uid, context=None):
         res={}
         payment_term = self.pool.get('account.payment.term').search(cr, uid, [('name', '=', '7 Days')])
         if payment_term:
             return payment_term[0]
         else:
             return False

    def _get_default_section_id(self, cr, uid, context=None):
        """ Gives default section by checking if present in the context """
        return self._resolve_section_id_from_context(cr, uid, context=context) or False

    def _get_default_stage_id(self, cr, uid, context=None):
        """ Gives default stage_id """
        print "Testing whether the Defult State Id Calling or Not Omme.........! "
        section_id = self._get_default_section_id(cr, uid, context=context)
        return self.stage_find(cr, uid, [], section_id, [('state', '=', 'draft')], context=context)

    def _resolve_section_id_from_context(self, cr, uid, context=None):
        """ Returns ID of section based on the value of 'section_id'
            context key, or None if it cannot be resolved to a single
            Sales Team.
        """
        if context is None:
            context = {}
        print "Context Testing Here ........",context.get('default_section_id')
        if type(context.get('default_section_id')) in (int, long):
            return context.get('default_section_id')
        if isinstance(context.get('default_section_id'), basestring):
            section_name = context['default_section_id']
            section_ids = self.pool.get('crm.case.section').name_search(cr, uid, name=section_name, context=context)
            if len(section_ids) == 1:
                print "Testing Here the Section Ids Omme.............. Resolve section Id from Context.... "
                return int(section_ids[0][0])
        return None

    def create(self, cr, uid, vals, context=None):
        res = super(crm_lead_new, self).create(cr, uid, vals, context=context)
        if uid == SUPERUSER_ID:
           return res
        else:
            self.write(cr, SUPERUSER_ID, [res], {'stage_id': vals.get('stage_id')}, context=context)
            return res
        return res

    def write(self, cr, uid, ids, vals, context=None):
        group_name = []
        if isinstance(ids, (int,long)):
            ids = [ids]
        if vals.get('stage_id') and not vals.get('probability'):
            # change probability of lead(s) if required by stage
            stage = self.pool.get('crm.case.stage').browse(cr, uid, vals['stage_id'], context=context)
            lead = self.browse(cr, uid, ids[0],context=context)
            for group in self.pool.get('res.users').browse(cr, uid, uid, context=context).groups_id:
                group_name.append(group.name or '')
            if not lead.partner_id:
                if lead.send_without_trade_ref == True and not lead.address_trade_ref_ids:
                    raise osv.except_osv(_('Warning!'), _('Please verify the Trade reference'))
                if stage.name == 'New':
                    if ('Finance Manager' in group_name or 'Sale Manager' in group_name) and (lead.state in ['open','cancel']):
                        raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot go back..!'))
                if stage.name == 'Waiting For Approval':
                    if ('Finance Manager' in group_name or 'Sale Manager' in group_name) and lead.state != 'draft':
                        raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot go back..!'))
                if stage.name == 'Approved By Sales Manager':
                    if ('Finance Manager' in group_name or 'Sale Manager' in group_name) and lead.state == 'cancel':
                        raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot go back..!'))
                    if 'Finance Manager' in group_name and 'approved_by_manager' != True and lead.state == 'open':
                        raise osv.except_osv(_('Warning!'), _('Sorry!,Only Sale Manager can do this action....!'))
                    else:
                        self.write(cr, uid, ids, {'approved_by_manager': True,
                                'sm_aprove_date': fields.date.context_today(self,cr, uid, context)}, context=context)
                if stage.name == 'Approved':
                    if 'Finance Manager' in group_name:
                        if ('approved_by_manager' == False) and (lead.state == 'open'):
                            raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot approve a customer registration request before the approval of Sale Manager..!'))
                        else:
                            partner_id = self._create_lead_partner(cr, uid, lead, context)
                            delivary_partner = self._lead_create_partner(cr, uid, lead, partner_id, context)
                            vals['partner_id'] = int(partner_id)
                            self.write(cr, uid, ids, {
                                'fc_aprove_date': fields.date.context_today(self,cr, uid, context)},
                                        context=context)
                    elif 'Sale Manager' in group_name:
                        raise osv.except_osv(_('Warning!'), _('Sorry!,Only Finance Manager can approve new customer registration request..!'))
                if stage.name == 'Dead':
                    if 'Sale Manager' in group_name and lead.approved_by_manager == True:
                        raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot cancel an approved customer registration request..!'))
                    elif 'Finance Manager' in group_name and lead.approved_by_manager == False and lead.state != 'draft':
                        raise osv.except_osv(_('Warning!'), _('Sorry!,You cannot cancel a customer registration request before the approval of Sale Manager..!'))
                if stage.on_change:
                    vals['probability'] = stage.probability
            else:
                del vals['stage_id']
        return super(lead_new, self).write(cr, uid, ids, vals, context=context)


    def lead_send_mail(self, cr, uid, ids, template_name, context=None):
        assert len(ids) == 1, 'This option should only be used for a single id at a time.'
        ir_model_data = self.pool.get('ir.model.data')
        try:
            template_id = ir_model_data.get_object_reference(cr, uid, 'r3x_crm_lead_customization', template_name)[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference(cr, uid, 'mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = dict(context)
        ctx.update({
            'default_model': 'crm.lead',
            'default_res_id': ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'default_type': ''
        })

        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    def approve_lead_button(self, cr, uid, ids, context=None):
        template_name = 'email_template_crm_lead_confirmation'
        if context is None:
            context = {}
        crm_obj=self.browse(cr, uid, ids, context=context)[0]
        context.update({'approval_status': 'wait'})
        res = self.lead_send_mail(cr, uid, ids, template_name, context)
        return res

    def confirm_lead_button(self, cr, uid, ids, context=None):
        template_name = 'email_template_crm_lead_customer_mail'
        if context is None:
            context = {}
        crm_obj=self.browse(cr, uid, ids, context=context)[0]
        context.update({'approval_status': 'wait_for_fm'})
        res = self.lead_send_mail(cr, uid, ids, template_name, context)
        return res

    def reject_lead_button(self, cr, uid, ids, context=None):
        template_name = 'email_template_crm_lead_reject'
        context.update({'approval_status': 'reject'})
        res = self.lead_send_mail(cr, uid, ids, template_name, context)
        return res

    def send_for_approval(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        crm_obj=self.browse(cr, uid, ids, context=context)[0]
        if crm_obj.approval_sel == 'sale_mngr':
            template_name = 'email_template_crm_lead2'
        else:
            template_name = 'email_template_crm_lead1'
        if crm_obj.customer_registration == 'trade':
            if crm_obj.send_without_trade_ref == True:
                if crm_obj.address_trade_ref_ids:
                    context.update({'approval_status': 'new'})
                else:
                    raise osv.except_osv(_('Warning!'), _('Please verify the Trade reference'))
            else:
                context.update({'approval_status': 'new'})
        else:
            context.update({'approval_status': 'new'})
        if crm_obj.approval_sel == 'sale_mngr':
            context.update({'approval_by': 'sale_mngr'})
        else:
            context.update({'approval_by': 'finance_mngr'})
        res = self.lead_send_mail(cr, uid, ids, template_name, context)
        return res
            
    _defaults = {
       'sm_property_payment_term': _get_payment_term,
       'fc_property_payment_term': _get_payment_term,
       'approval_mail_send': False,
       'send_without_trade_ref': False,
       'approved_by_manager': False,
       'mgr_mail_not_send': False,
       'date_incoprated': fields.date.context_today,
       'state': 'draft',
       'stage_id': lambda s, cr, uid, c: s._get_default_stage_id(cr, uid, c),
       'approval_sel': 'sale_mngr',
       'customer_registration': 'trade',
       'send_without_trade_ref': True
    }

crm_lead_new()

class mail_compose_message(osv.osv):
    _inherit = 'mail.compose.message'

    def send_mail(self, cr, uid, ids, context=None):
        context = context or {}
        if context.get('default_model', False) and context['default_model'] == 'crm.lead':
            crm_id = context['default_res_id']
            if context.get('approval_status', False) == 'new':
                if context.get('approval_by', False) == 'sale_mngr':
                    self.pool.get('crm.lead').write(cr, SUPERUSER_ID, crm_id, {
                                'completed_date': fields.date.context_today(self,cr, uid, context),
                                'stage_id': self.pool.get('crm.case.stage').search(cr, uid, [('name', '=', 'Waiting For Approval')])[0]} ,
                                                     context=context)
                elif context.get('approval_by', False) == 'finance_mngr':
                     self.pool.get('crm.lead').write(cr, SUPERUSER_ID, crm_id, {
                                'approved_by_manager': True, 'mgr_mail_not_send': True,
                                'completed_date': fields.date.context_today(self,cr, uid, context),
                                'stage_id': self.pool.get('crm.case.stage').search(cr, uid, [('name', '=', 'Approved By Sales Manager')])[0]} ,
                                                      context=context)
            if context.get('approval_status',False) == 'wait':
                self.pool.get('crm.lead').write(cr, uid, crm_id, {'approved_by_manager': True,'mgr_mail_not_send': True, 'stage_id': self.pool.get('crm.case.stage').search(cr, uid, [('name', '=', 'Approved By Sales Manager')])[0]} , context=context)
            if context.get('approval_status',False) == 'wait_for_fm':
                self.pool.get('crm.lead').write(cr, uid, crm_id, {'approval_mail_send': True, 'stage_id': self.pool.get('crm.case.stage').search(cr, uid, [('name', '=', 'Approved')])[0]} , context=context)
            elif context.get('approval_status',False) == 'reject':
                self.pool.get('crm.lead').write(cr, uid, crm_id, {'stage_id': self.pool.get('crm.case.stage').search(cr, uid, [('name', '=', 'Dead')])[0]} , context=context)
        return super(mail_compose_message, self).send_mail(cr, uid, ids, context=context)

mail_compose_message()
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: